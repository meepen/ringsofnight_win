#include "resources.h"
namespace RON
{
	char *ResourceNames[MAX_RESOURCES] = {
		"Organics",
		"Gases",
		"Metals",
		"Radioactives",
		"DarkMatter",
	};
}