namespace RON
{
	char *DirectionNames[] = {
		"North",
		"Northeast",
		"East",
		"Southeast",
		"South",
		"Southwest",
		"West"
		"Northwest",
	};
}